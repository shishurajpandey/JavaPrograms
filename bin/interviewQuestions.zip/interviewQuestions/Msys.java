package interviewQuestions;

public class Msys {

	public static void main(String[] args) {
		int x=1;
		boolean X=true;
		while(X) //X should be boolean
		{
			System.out.println("hello");
		}

	}

}
